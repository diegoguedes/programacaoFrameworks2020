package br.com.diego.notafiscal;

import java.math.BigDecimal;

public abstract class Imposto {
	public abstract BigDecimal valorImposto();
}