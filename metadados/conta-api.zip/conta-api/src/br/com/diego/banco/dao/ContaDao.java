package br.com.diego.banco.dao;

import java.util.List;

import br.com.diego.banco.modelo.Conta;

public interface ContaDao {
	public List<Conta> lista();
	public Conta getConta(Integer id);
}
