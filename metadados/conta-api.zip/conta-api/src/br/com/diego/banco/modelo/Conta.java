package br.com.diego.banco.modelo;

public class Conta {
	private String nome;
	private double saldo;
	private String cpf;

	public Conta(String nome, double saldo, String cpf) {
		this.nome = nome;
		this.saldo = saldo;
		this.cpf = cpf;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public double getSaldo() {
		return saldo;
	}

	public void setSaldo(double saldo) {
		this.saldo = saldo;
	}

	public String getCpf() {
		return cpf;
	}

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}

	@Override
	public String toString() {
		return "Conta [nome=" + nome + ", saldo=" + saldo + ", cpf=" + cpf + "]";
	}
}
