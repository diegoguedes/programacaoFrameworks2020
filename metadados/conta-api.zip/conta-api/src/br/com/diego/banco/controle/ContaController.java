package br.com.diego.banco.controle;

import java.util.List;
import java.util.stream.Collectors;

import br.com.diego.banco.dao.ContaDaoMock;
import br.com.diego.banco.modelo.Conta;

public class ContaController {
	
	private ContaDaoMock contaDao;

	public ContaController() {
		contaDao = new ContaDaoMock();
	}
	
	public List<Conta> lista() {
		return contaDao.lista();
	}
	
	public List<Conta> filtra(String nome) {
		return contaDao.lista().stream()
							.filter(conta -> conta.getNome().toLowerCase().startsWith(nome.toLowerCase()))
							.collect(Collectors.toList());
	}
	
	public List<Conta> filtra(String nome, String cpf) {
		return contaDao.lista().stream()
							.filter(conta -> 
								conta.getNome().toLowerCase().startsWith(nome.toLowerCase())
								&& conta.getCpf().equalsIgnoreCase(cpf)
							)
							.collect(Collectors.toList());
	}
}
