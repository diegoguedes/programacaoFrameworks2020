package br.com.diego.banco.dao;

import java.util.Arrays;
import java.util.List;

import br.com.diego.banco.modelo.Conta;

public class ContaDaoMock implements ContaDao {
	private static final List<Conta> LISTA_CONTA = 
			Arrays.asList(new Conta("diego", 20.0, "12345678900"),
					new Conta("joao", 30.0, "98765432100"),
					new Conta("jose", 40.0, "14725836900"));
	
	public List<Conta> lista() {
		return LISTA_CONTA;
	}
	
	public Conta getConta(Integer id) {
		return LISTA_CONTA.get(id);
	}
}
