package br.com.diego.banco;

import java.util.Scanner;
import br.com.diego.summer.Summer;

public class Main {
	/**
	 * Simula o navegador.
	 * 
	 */
	public static void main(String[] args) throws Exception {
		Summer summer = null;

		try (Scanner s = new Scanner(System.in)) {
			String url = s.nextLine();

			while (!url.equals("exit")) {
				summer = new Summer(url);
				Object response = summer.executa();
				System.out.println("Resposta: " + response);

				url = s.nextLine();
			}
		}
	}
}
