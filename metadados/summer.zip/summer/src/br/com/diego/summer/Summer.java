package br.com.diego.summer;

import java.lang.reflect.InvocationTargetException;

public class Summer {
	private String caminhoClasse="";

	public Summer(String url) {
		String[] partesUrl = url.replaceFirst("/", "").split("/");
		if (partesUrl[0].compareTo("conta") == 0)
			this.caminhoClasse = "br.com.diego.banco.controle.ContaController";
	}

	public Object executa() {
		try {
			Class<?> classeControle = Class.forName(caminhoClasse);

			Object instanciaControle = classeControle.getConstructor().newInstance();

			System.out.println(instanciaControle);
		} catch (ClassNotFoundException | InstantiationException | IllegalAccessException | IllegalArgumentException
				| NoSuchMethodException | SecurityException e) {
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			e.printStackTrace();
			throw new RuntimeException("Erro no construtor", e.getTargetException());
		}
		return null;
	}
}
