package br.com.diego.banco.controle;

import java.util.List;

public class Conta {		
	private List<String> lista = List.of("item 1", "item 2", "item 3");
	
	public Conta() {}
	
	public Conta(String nome) {}
	
	public Conta(String nome, Double saldo) {}
	
	
	public List<String> getLista() {
		return lista;
	}
}
