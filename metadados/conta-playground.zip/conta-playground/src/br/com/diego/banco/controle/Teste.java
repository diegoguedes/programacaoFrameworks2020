package br.com.diego.banco.controle;

public interface Teste {

}
