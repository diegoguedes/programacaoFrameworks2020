package br.com.diego.banco.controle;

public class ContaCorrente extends Conta {
	public ContaCorrente() {
	}

	public ContaCorrente(String nome) {
	}
}
