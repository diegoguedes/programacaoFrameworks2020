package br.com.diego.conta.playground.reflexao;


public class TesteInstanciaObjeto {
	public static void main(String[] args) {
		
	}
}
